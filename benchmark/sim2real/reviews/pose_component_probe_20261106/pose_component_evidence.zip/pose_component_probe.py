"""Paired synthetic pose decomposition and inference-only controls."""
import argparse
import ast
import hashlib
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from scipy.spatial import cKDTree

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--campaign', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--helper', type=Path, required=True)
parser.add_argument('--seeds', type=int, nargs='+', default=[0])
args = parser.parse_args()
R = args.campaign
device = torch.device('cuda:0')
assert torch.cuda.device_count() == 1
torch.set_num_threads(2)
torch.set_num_interop_threads(1)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
cv2.setNumThreads(1)

helper = ast.parse(args.helper.read_text())
definitions = [node for node in helper.body if isinstance(node, ast.FunctionDef)
               and node.name in {'load', 'decode', 'sha', 'dump'}]
exec(compile(ast.Module(body=definitions, type_ignores=[]), str(args.helper), 'exec'))
source = R.parents[2] / 'external/sources/downstream/SingleShotPose'
sys.path.insert(0, str(source))
from darknet import Darknet

frozen = json.loads((R / 'recovery_20261103/pose_frozen_checkpoints.json').read_text())
assets = json.loads((R / 'recovery_20261105_mainline/pose_prepared_full_v5/protocol.json').read_text())['assets']
vertices_path = Path(assets['vertices']['path'])
assert sha(vertices_path) == assets['vertices']['sha256']
vertices = np.load(vertices_path, allow_pickle=False)
tree = cKDTree(vertices)
threshold = 0.1 * assets['diameter_m']
cases = ['epnp', 'epnp_lm', 'gt_rotation', 'gt_center_translation', 'gt_depth', 'gt_image_ray']


def metric(truth_points, rotation, translation):
    return float(tree.query((truth_points - translation) @ rotation, workers=1)[0].mean())


def solve(sample, predicted):
    keys = np.asarray(sample['keys'], dtype=np.float64)
    corners = np.ascontiguousarray(predicted[1:], dtype=np.float64)
    K = np.asarray(sample['K'], dtype=np.float64)
    answers = dict.fromkeys(cases)
    ok, rvec, tvec = cv2.solvePnP(keys[1:], corners, K, None, flags=cv2.SOLVEPNP_EPNP)
    if not ok:
        return answers, {}
    rotation = cv2.Rodrigues(rvec)[0]
    translation = tvec[:, 0]
    if not np.isfinite(rotation).all() or not np.isfinite(translation).all():
        return answers, {}
    if not ((keys @ rotation.T + translation)[:, 2] > 0).all():
        return answers, {}
    gt_rotation = sample['T'][:3, :3]
    gt_translation = sample['T'][:3, 3]
    truth = vertices @ gt_rotation.T + gt_translation
    center = keys[0]
    predicted_center = rotation @ center + translation
    true_center = gt_rotation @ center + gt_translation
    answers['epnp'] = metric(truth, rotation, translation)
    try:
        lm_rvec, lm_tvec = cv2.solvePnPRefineLM(keys[1:], corners, K, None, rvec.copy(), tvec.copy())
        lm_rotation = cv2.Rodrigues(lm_rvec)[0]
        lm_translation = lm_tvec[:, 0]
        if np.isfinite(lm_translation).all() and ((keys @ lm_rotation.T + lm_translation)[:, 2] > 0).all():
            answers['epnp_lm'] = metric(truth, lm_rotation, lm_translation)
    except cv2.error:
        pass
    answers['gt_rotation'] = metric(truth, gt_rotation, predicted_center - gt_rotation @ center)
    answers['gt_center_translation'] = metric(truth, rotation, true_center - rotation @ center)
    corrected_depth = predicted_center * (true_center[2] / predicted_center[2])
    corrected_ray = true_center * (predicted_center[2] / true_center[2])
    answers['gt_depth'] = metric(truth, rotation, corrected_depth - rotation @ center)
    answers['gt_image_ray'] = metric(truth, rotation, corrected_ray - rotation @ center)
    auxiliary = dict(center_error_m=float(np.linalg.norm(predicted_center - true_center)),
                     depth_error_m=float(abs(predicted_center[2] - true_center[2])))
    return answers, auxiliary


def summarize(rows):
    groups = [[row for row in rows if row['rollout'] == rollout]
              for rollout in sorted({row['rollout'] for row in rows})]
    summary = {}
    for case in cases:
        values = [row['errors'][case] for row in rows if row['errors'][case] is not None]
        success = [[row['errors'][case] is not None and row['errors'][case] < threshold for row in group]
                   for group in groups]
        auc = [[max(1 - row['errors'][case] / 0.1, 0) if row['errors'][case] is not None else 0
                for row in group] for group in groups]
        summary[case] = dict(success=float(np.mean([np.mean(group) for group in success])),
                             auc_0_1m=float(np.mean([np.mean(group) for group in auc])),
                             valid=len(values), median_m=float(np.median(values)) if values else None)
    summary['epe_px'] = float(np.mean([np.mean([row['epe_px'] for row in group]) for group in groups]))
    return summary


args.out.mkdir(parents=True, exist_ok=False)
dump(args.out / 'protocol.json', dict(scope='synthetic validation only', seeds=args.seeds,
     methods=['eventgenesis', 'v2e'], checkpoints=['frozen_EPE_best', 'last_30000'],
     denominator='all510 windows, equal32 rollouts, invalid counts as failure',
     oracle_semantics='GT substitutions are diagnostic, translation defined at CAD center',
     non_oracle_cases=['epnp', 'epnp_lm'], helper_sha256=sha(args.helper), real_data_used=False))
results = []
for method in ['eventgenesis', 'v2e']:
    samples = load(method, 'validation')
    assert len(samples) == 510 and len({sample['rid'] for sample in samples}) == 32
    for seed in args.seeds:
        binding = next(row for row in frozen['runs'] if row['method'] == method and row['seed'] == seed)
        for checkpoint in ['synthetic_best.pt', 'last.pt']:
            path = Path(binding['selected_checkpoint']).parent / checkpoint
            expected = binding['selected_checkpoint_sha256' if checkpoint == 'synthetic_best.pt' else 'last_checkpoint_sha256']
            assert sha(path) == expected
            payload = torch.load(path, map_location='cpu', weights_only=False)
            update = payload['completed_update']
            assert (payload['generator'], payload['seed']) == (method, seed)
            assert checkpoint != 'last.pt' or update == 30000
            model = Darknet(str(source / 'cfg/yolo-pose.cfg')).to(device)
            model.load_state_dict(payload['model'], strict=True)
            model.eval()
            del payload
            predictions = []
            with torch.inference_mode():
                for offset in range(0, len(samples), 8):
                    inputs = np.stack([row['image'] for row in samples[offset:offset + 8]])
                    coordinates, _ = decode(model(torch.from_numpy(inputs).to(device)))
                    predictions.extend(coordinates)
            del model
            rows = []
            for sample, coordinates in zip(samples, predictions, strict=True):
                predicted = coordinates * [346, 260]
                errors, auxiliary = solve(sample, predicted)
                rows.append(dict(sample=sample['id'], rollout=sample['rid'], errors=errors, **auxiliary,
                                 epe_px=float(np.linalg.norm(predicted - sample['uv'] * [346, 260], axis=1).mean())))
            summary = summarize(rows)
            recorded = json.loads((path.parent / f'synthetic_validation_{update:06d}.json').read_text())
            assert abs(summary['epe_px'] - recorded['mean_keypoint_epe_px']) < 0.002
            tag = f'{method}_seed{seed}_{path.stem}'
            item = dict(method=method, seed=seed, checkpoint=checkpoint, update=update,
                        source_sha256=expected, summary=summary)
            dump(args.out / f'{tag}.json', dict(item, rows=rows))
            results.append(item)
            print('POSE_COMPONENT_CASE', json.dumps(item), flush=True)
dump(args.out / 'completion.json', dict(status='complete', real_data_used=False, results=results))
