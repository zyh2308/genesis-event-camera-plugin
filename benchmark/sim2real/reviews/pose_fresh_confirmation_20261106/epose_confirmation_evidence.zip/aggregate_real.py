import json,numpy as np,sys
from pathlib import Path
p=Path(sys.argv[1]); out=Path(sys.argv[2])
d=json.loads(p.read_text())['results']
primary='untouched_primary'; seqs=sorted({r['sequence'] for r in d if r['group']==primary})
assert len(seqs)==16
index={(r['tag'],r['sequence']):r['summary'] for r in d}
cases=['original','median','center_median','learned']
metrics=['success','depth_mae_m','auc']
methods=['eventgenesis','v2e']
def matrix(m,case,metric):
 return np.array([[index[(f'{m}_seed{s}',n)][case][metric] for n in seqs] for s in range(3)])
rng=np.random.default_rng(20261107)
draws=rng.integers(len(seqs),size=(10000,len(seqs)))
def effect(a,b):
 delta=a-b; dist=delta.mean(0)[draws].mean(1)
 return dict(mean=float(delta.mean()),ci=[float(x) for x in np.quantile(dist,[.025,.975])],per_seed=delta.mean(1).tolist())
summary={}
for m in methods:
 summary[m]={}
 for case in cases:
  summary[m][case]={}
  for metric in metrics:
   values=matrix(m,case,metric).mean(1)
   summary[m][case][metric]=dict(mean=float(values.mean()),sd=float(values.std(ddof=1)),seeds=values.tolist())
 effects={b:{k:effect(matrix(m,'learned',k),matrix(m,b,k)) for k in metrics} for b in cases[:-1]}
 summary[m]['paired_learned_minus_control']=effects
comparison={k:effect(matrix('eventgenesis','learned',k),matrix('v2e','learned',k)) for k in metrics}
result=dict(group=primary,sequences=seqs,samples=sum(next(x['samples'] for x in d if x['sequence']==n) for n in seqs),
       per_method=summary,paired_learned_eventgenesis_minus_v2e=comparison,
       bootstrap=dict(replicates=10000,seed=20261107,unit='sequence',seeds_averaged_before_resampling=True))
with out.open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
for m in methods:
 for b in cases[:-1]:
  print(m,b,{k:[round(100*summary[m]['paired_learned_minus_control'][b][k]['mean'],2),*[round(100*x,2) for x in summary[m]['paired_learned_minus_control'][b][k]['ci']]] for k in metrics})
print('EG_MINUS_V2E',{k:[round(100*v['mean'],2),*[round(100*x,2) for x in v['ci']]] for k,v in comparison.items()})
