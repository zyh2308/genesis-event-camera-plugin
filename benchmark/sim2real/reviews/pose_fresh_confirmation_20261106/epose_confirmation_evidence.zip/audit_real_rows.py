import json,sys,math,hashlib
from pathlib import Path
from statistics import mean
from itertools import groupby,zip_longest
p,original=map(Path,sys.argv[1:])
truth=json.loads((p/'completion.json').read_text())['results']
ref={(x['tag'],x['sequence']):x for x in truth}
threshold=.1*.23736661851784532
audit=[]
for tag in sorted({r['tag'] for r in truth}):
 q=p/(tag+'.jsonl'); source=original/(tag+'_predictions.jsonl')
 count=0
 with q.open() as output,source.open() as base:
  pairs=((json.loads(a),json.loads(b)) for a,b in zip_longest(output,base))
  for seq,g in groupby(pairs,key=lambda item:item[0]['rollout']):
   group=list(g); r=ref[(tag,seq)]
   assert len(group)==r['samples'] and len({x['sample'] for x,y in group})==len(group)
   assert all(x['sample']==y['index'] and x['rollout']==y['sequence'] and x['adds_m']['original']==y['adds_m'] for x,y in group)
   for k,v in r['summary'].items():
    a=[x['adds_m'][k] for x,y in group]
    ds=[abs(x['predicted_depth_m'][k]-x['gt_depth_m']) for x,y in group if x['predicted_depth_m'][k] is not None]
    assert v['valid']==sum(e is not None for e in a) and v['depth_valid']==len(ds)
    assert math.isclose(v['success'],mean(e is not None and e<threshold for e in a))
    assert math.isclose(v['auc'],mean(0 if e is None else max(0,1-e/.1) for e in a))
    assert math.isclose(v['depth_mae_m'],mean(ds))
   count+=len(group)
 assert count==20916
 audit.append(dict(tag=tag,rows=count,sha256=hashlib.sha256(q.read_bytes()).hexdigest(),bytes=q.stat().st_size,path=str(q)))
with (p/'raw_score_audit.json').open('x') as f:
 json.dump(dict(passed=True,verified_runs=len(audit),rows_per_run=20916,original_scores_matched=True,rows=audit),f,indent=2)
print('RAW_VERIFY',len(audit),sum(x['rows'] for x in audit))
