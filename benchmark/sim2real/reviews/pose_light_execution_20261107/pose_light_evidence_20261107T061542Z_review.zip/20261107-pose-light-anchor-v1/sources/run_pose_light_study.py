"""Run the bounded paired pose study under the project's atomic GPU reservation."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import traceback


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    temp = path.with_name(path.name+'.tmp')
    temp.write_text(json.dumps(value, indent=2)+'\n')
    temp.replace(path)


def stop_child(child):
    if child.poll() is not None:
        return
    os.killpg(child.pid, signal.SIGTERM)
    try:
        child.wait(timeout=30)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGKILL)
        child.wait()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--campaign', required=True, type=Path)
    parser.add_argument('--gpu-index',type=int,default=5)
    parser.add_argument('--gpu-uuid',default='GPU-06ee62ba-c171-40d4-b4ae-ea63391dc885')
    parser.add_argument('--training-only',action='store_true')
    parser.add_argument('--anchored',action='store_true')
    args = parser.parse_args()
    root, campaign = args.root.resolve(), args.campaign.resolve()
    assert socket.gethostname() == 'g1'
    assert root.parent == campaign.parent and root != campaign
    uuid = args.gpu_uuid
    assert uuid.startswith('GPU-') and 0<=args.gpu_index<6
    observed=subprocess.check_output(['nvidia-smi','-i',str(args.gpu_index),'--query-gpu=uuid','--format=csv,noheader'],text=True).strip()
    assert observed==uuid
    project = campaign.parents[2]
    src = root/'sources'
    manifest = json.loads((src/'source_manifest.json').read_text())
    for file, digest in manifest.items():
        assert hashlib.sha256((src/file).read_bytes()).hexdigest() == digest
    logs = root/'logs'
    logs.mkdir(exist_ok=False)
    registry = project/'.gpu_reservations'
    record = registry/(root.name+'_gpu'+str(args.gpu_index)+'.json')
    lock = (registry/('.gpu-'+uuid+'.lock')).open('a+')
    global_lock = (registry/'.gpu_reservations.lock').open('a+')
    fcntl.flock(global_lock, fcntl.LOCK_EX)
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid', '--format=csv,noheader'], text=True)
        assert uuid not in apps, 'Reserved GPU has active compute processes'
        for path in registry.glob('*.json'):
            existing = json.loads(path.read_text())
            if existing.get('gpu_uuid') == uuid:
                assert str(existing.get('status','')).startswith(('released','complete')), str(path)
        assert not record.exists()
        state = dict(owner='sim-to-real research chat', host='g1', gpu_index=args.gpu_index, gpu_uuid=uuid,
                     run_id=root.name, pid=os.getpid(), process_start_ticks=Path('/proc/self/stat').read_text().split()[21],
                     status='reserved', output_path=str(root), started_utc=now(), purpose='paired synthetic pose robustness')
        save(record, state)
    finally:
        fcntl.flock(global_lock, fcntl.LOCK_UN)
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=uuid, OMP_NUM_THREADS='2', MKL_NUM_THREADS='2',
               OPENBLAS_NUM_THREADS='1', NVIDIA_TF32_OVERRIDE='0', PYTHONDONTWRITEBYTECODE='1')
    specs = [
        ('smoke', 'pose_light_robustness.py', ['--campaign',str(campaign),'--out',str(root/'smoke'),'--smoke']),
        ('robustness', 'pose_light_robustness.py', ['--campaign',str(campaign),'--out',str(root/'robustness')]),
        ('radiance', 'prepare_pose_radiance_pairs.py', ['--campaign',str(campaign),'--out',str(root/'radiance'),'--replay']),
        ('radiance_score', 'evaluate_pose_radiance_pairs.py', ['--campaign',str(campaign),'--radiance',str(root/'radiance'),
                  '--robustness',str(root/'robustness'),'--out',str(root/'radiance_score')])]
    if args.training_only:specs=specs[:2]
    if args.anchored:
        for _,filename,options in specs:
            if filename=='pose_light_robustness.py':
                options.extend(['--arms','clean','augmented','anchored','--primary','anchored'])
    completed = []
    child = None
    try:
        for label, filename, options in specs:
            for file, digest in manifest.items():
                assert hashlib.sha256((src/file).read_bytes()).hexdigest() == digest
            command = [sys.executable,'-u',str(src/filename),*options]
            receipt = dict(phase=label, argv=command, started_utc=now(), status='running')
            with (logs/(label+'.log')).open('x') as log:
                child = subprocess.Popen(command, env=env, cwd=str(src), stdin=subprocess.DEVNULL,
                                         stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                receipt['pid'] = child.pid
                state.update(status='running', current_job=receipt, heartbeat_utc=now())
                save(record,state)
                save(root/'live.json',state)
                deadline=time.monotonic()+3*3600
                while child.poll() is None:
                    if time.monotonic() > deadline:
                        stop_child(child)
                        raise TimeoutError('Own study phase exceeded bounded runtime')
                    state['heartbeat_utc']=now()
                    save(record,state)
                    save(root/'live.json',state)
                    time.sleep(5)
                receipt.update(exit_code=child.returncode, finished_utc=now())
            save(root/(label+'_exit.json'),receipt)
            assert child.returncode == 0, (label,child.returncode)
            completion=json.loads((root/label/'completion.json').read_text())
            assert completion['status']=='complete' and not completion.get('real_data_used',False)
            if label=='smoke':assert len(completion['results'])==2
            completed.append(label)
            child=None
        save(root/'completion.json',dict(status='complete', completed=completed,real_data_used=False,finished_utc=now()))
    except BaseException:
        save(root/'failure.json',dict(status='failed',completed=completed,error=traceback.format_exc(),utc=now()))
        raise
    finally:
        if child is not None and child.poll() is None:
            stop_child(child)
        state.update(status='released',current_job=None,released_utc=now(),completed=completed)
        save(record,state)
        save(root/'resource_release.json',state)
        fcntl.flock(lock,fcntl.LOCK_UN)


if __name__=='__main__':main()
